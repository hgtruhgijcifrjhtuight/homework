import cv2
from Constants import HOURGLAS_VIDEO_SRC

# Функція для застосування низькочастотного фільтра до кадру
def apply_low_pass_filter(frame, kernel_size):
    # Створення маски для низькочастотного фільтра
    kernel = cv2.getGaussianKernel(kernel_size, 0)
    # Застосування фільтра до кадру
    filtered_frame = cv2.filter2D(frame, -1, kernel)
    
    return filtered_frame

# Відкриття відеопотоку за допомогою відеофайлу
cap = cv2.VideoCapture(HOURGLAS_VIDEO_SRC)

while cap.isOpened(): 
    # Зчитування кадру з відеопотоку
    ret, frame = cap.read()
    
    # Перевірка на успішне зчитування кадру
    if not ret:
        break

    # Застосування низькочастотного фільтра до кадру
    frame = apply_low_pass_filter(frame, 5)
    
    # Відображення відеопотока з фільтром
    cv2.imshow('Filter', frame)

    # Очікування натискання клавіші з кодом 'q' (для виходу з програми)
    if cv2.waitKey(25) == ord('q'):
        break

# Звільнення ресурсів відеопотоку та закриття вікон OpenCV
cap.release()
cv2.destroyAllWindows()