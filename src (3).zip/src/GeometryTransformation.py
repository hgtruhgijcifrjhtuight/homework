import cv2
from Constants import HOURGLAS_VIDEO_SRC

# Функція повороту кадру на заданий кут
def rotate(frame, angle):
    # Отримання висоти та ширини кадру
    num_rows, num_cols = frame.shape[:2]
    # Створення матриці повороту
    rotation_matrix = cv2.getRotationMatrix2D((num_cols / 2, num_rows / 2), angle, 1)
    # Поворот кадру за допомогою отриманої матриці 
    img_rotation = cv2.warpAffine(frame, rotation_matrix, (num_cols, num_rows)) 
    return img_rotation


# Відкриття відеопотоку за допомогою відеофайлу
cap = cv2.VideoCapture(HOURGLAS_VIDEO_SRC)

while cap.isOpened():
    # Зчитування кадру з відеопотоку
    ret, frame = cap.read()
    
    # Перевірка на успішне зчитування кадру
    if not ret:
        break

    # Поворот фрейму на 90 градусів
    frame = rotate(frame, 90)
    
    # Відображення кадру з відео
    cv2.imshow('Rotated Frame', frame)

    # Очікування натискання клавіші з кодом ASCII 'q' (для виходу з програми)
    if cv2.waitKey(25) == ord('q'):
        break

# Звільнення ресурсів відеопотоку та закриття вікон OpenCV
cap.release()
cv2.destroyAllWindows()
