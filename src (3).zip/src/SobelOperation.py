import cv2
from Constants import HOURGLAS_VIDEO_SRC

# Функція для застосування оператора Собеля для виявлення країв
def sobel_edge_detection(image, k_size):
    # Перетворення зображення у відтінки сірого
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    # Застосування оператора Собеля по горизонталі
    sobel_x = cv2.Sobel(gray_image, -1, 1, 0, k_size)
    # Застосування оператора Собеля по вертикалі
    sobel_y = cv2.Sobel(gray_image, -1, 0, 1, k_size)
    # Об'єднання результатів за допомогою апроксимації величини градієнту
    sobel_xy = sobel_x + sobel_y

    return sobel_xy


# Відкриття відеопотоку за допомогою відеофайлу
cap = cv2.VideoCapture(HOURGLAS_VIDEO_SRC)

while cap.isOpened(): 
    # Зчитування кадру з відеопотоку
    ret, frame = cap.read()
    
    # Перевірка на успішне зчитування кадру
    if not ret:
        break

    # Перетворення для виявлення країв оператором Собеля
    frame = sobel_edge_detection(frame, 10)
    
    # Відображення кадру з відео
    cv2.imshow('Sobel', frame)

    # Очікування натискання клавіші з кодом ASCII 'q' (для виходу з програми)
    if cv2.waitKey(25) == ord('q'):
        break

# Звільнення ресурсів відеопотоку та закриття вікон OpenCV
cap.release()
cv2.destroyAllWindows()
