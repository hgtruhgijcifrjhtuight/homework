from VideoProcessor import VideoProcessor, Media, Mode
from Constants import GAME_VIDEO_SRC, HOURGLAS_VIDEO_SRC # Імпорт посилань на відеофайли

def main():
    # Обирання джерела відео
    media_choice = input("Оберіть джерело відео: (1 - з файлу, 2 - веб-камера): ")
    if media_choice == "1":
         # Обирання відеофайлу
        video_choice = input("Оберіть відеофайл: (1 - Hourglass.mp4, 2 - Game.mp4): ")
        if video_choice == "1":
            video_src = HOURGLAS_VIDEO_SRC
        elif video_choice == "2":
            video_src = GAME_VIDEO_SRC
        else:
            print("Невірний вибір. Завершення програми.")
            return
        media = Media.FROM_FILE
    elif media_choice == "2":
        media = Media.WEBCAMERA
        video_src = 0
    else:
        print("Невірний вибір. Завершення програми.")
        return

    # Обирання режиму обробки відео
    mode_choice = input("Оберіть режим обробки відео: (1 - Геометрична трансформація, 2 - Кольорова трансформація, "
                            "3 - Шумозаглушення, 4 - Виявлення країв Собелем, 5 - Звичайне відео): ")
    if mode_choice not in ["1", "2", "3", "4", "5", "6"]:   # Якщо обране невірне значення
        print("Невірний вибір. Завершення програми.")
        return

    # Створення екземпляру класу VideoProcessor
    processor = VideoProcessor(video_src)
    processor.set_media(Media(media)) # Встановленя джерела 
    processor.set_mode(Mode(int(mode_choice))) # Встановленя режиму обробки відео2 
    processor.show() # Запуск відтворення відео

# При запуску як головного файлу
if __name__ == "__main__":
    main()
