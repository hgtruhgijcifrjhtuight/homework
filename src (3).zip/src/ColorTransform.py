import cv2
from Constants import HOURGLAS_VIDEO_SRC

# Відкриття відеопотоку за допомогою відеофайлу
cap = cv2.VideoCapture(HOURGLAS_VIDEO_SRC)

while cap.isOpened(): 
    # Зчитування кадру з відеопотоку
    ret, frame = cap.read()
    
    # Перевірка на успішне зчитування кадру
    if not ret:
        break

    # Перетворення кольорового простору в RGB
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    
    # Відображення кадру з відео
    cv2.imshow('RGB', frame_rgb)

    # Очікування натискання клавіші з кодом ASCII 'q' (для виходу з програми)
    if cv2.waitKey(25) == ord('q'):
        break

# Звільнення ресурсів відеопотоку та закриття вікон OpenCV
cap.release()
cv2.destroyAllWindows()
