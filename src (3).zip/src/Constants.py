HOURGLAS_VIDEO_SRC = "src/data/Hourglass.mp4"
GAME_VIDEO_SRC = "src/data/Game.mp4"