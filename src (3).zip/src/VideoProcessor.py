import cv2
from enum import Enum

class Media(Enum):
    FROM_FILE = 1   # Завантаження відео з файлу
    WEBCAMERA = 2   # Завантаження відео з вебкамери   

class Mode(Enum):
    GEOMETRY_TRANSFORMATION = 1 # Поворот на 45 градусів
    COLOR_TRANSFORMATION = 2    # Колірне перетворення в RGB
    NOISE_FILTRATION = 3        # Низькочастотна фільтрація
    SOBEL = 4                   # Оператора Собеля для виявлення країв
    DEFAULT = 5                 # Виведення звичайного відео

class VideoProcessor:
    # Конструктор
    def __init__(self, video_src):
        self.video_src = video_src      # Шлях до файлу
        self.media = Media.FROM_FILE    # За замовчуванням використовується завантаження відео з файлу
        self.mode = Mode.DEFAULT        # За замовчуванням використовується режим без змін  

    # Встановлення режиму обробки
    def set_mode(self, mode):
        self.mode = mode

    # Встановлення джерело
    def set_media(self, media):
        self.media = media

    # Відтворення відео та застосування обробки. 
    def show(self):
        cap = cv2.VideoCapture(self.video_src)
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break

            frame = self.__process(frame)

            cv2.imshow('frame', frame)
            if cv2.waitKey(25) == ord('q'):
                break
        cap.release()
        cv2.destroyAllWindows()
    
    # Функція обробки кадру в залежності від обраного режиму
    def __process(self, frame):
        if self.mode == Mode.DEFAULT:
            return frame
        if self.mode == Mode.GEOMETRY_TRANSFORMATION:
            return self.__rotate(frame, 45)
        if self.mode == Mode.COLOR_TRANSFORMATION:
            return cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        if self.mode == Mode.NOISE_FILTRATION:
            return self.__apply_low_pass_filter(frame, 5)
        if self.mode == Mode.SOBEL:
            return self.__sobel_edge_detection(frame, 5)
    
    # Функція повороту кадру на заданий кут
    def __rotate(self, frame, angle):
        # Отримання висоти та ширини кадру
        num_rows, num_cols = frame.shape[:2]
        # Створення матриці повороту
        rotation_matrix = cv2.getRotationMatrix2D((num_cols / 2, num_rows / 2), angle, 1)
        # Поворот кадру за допомогою отриманої матриці 
        img_rotation = cv2.warpAffine(frame, rotation_matrix, (num_cols, num_rows)) 
        return img_rotation
    
    # Функція для застосування низькочастотного фільтра до кадру
    def __apply_low_pass_filter(self, frame, kernel_size):
        # Створення маски для низькочастотного фільтра
        kernel = cv2.getGaussianKernel(kernel_size, 0)
        # Застосування фільтра до кадру
        filtered_frame = cv2.filter2D(frame, -1, kernel)
        return filtered_frame
    
    # Функція для застосування оператора Собеля для виявлення країв
    def __sobel_edge_detection(self, frame, k_size):
        # Перетворення зображення у відтінки сірого
        gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        # Застосування оператора Собеля по горизонталі
        sobel_x = cv2.Sobel(gray_frame, -1, 1, 0, k_size)
        # Застосування оператора Собеля по вертикалі
        sobel_y = cv2.Sobel(gray_frame, -1, 0, 1, k_size)
        # Об'єднання результатів за допомогою апроксимації величини градієнту
        sobel_xy = sobel_x + sobel_y
        return sobel_xy
    
    