import cv2
from Constants import HOURGLAS_VIDEO_SRC

# Відкриття відеопотоку за допомогою відеофайлу
cap = cv2.VideoCapture(HOURGLAS_VIDEO_SRC)

while cap.isOpened():
    # Запис кадру з відеопотоку
    ret, frame = cap.read()

    # При завешенні відображеня виходимо з циклу
    if not ret:
        break

    # Відображення відеопотока з відео
    cv2.imshow('frame', frame)

    # Вихід з програми натисканням клавіши q
    if cv2.waitKey(25) == ord('q'):
        break

# Звільнення ресурсів відеопотоку та закриття вікон OpenCV
cap.release()
cv2.destroyAllWindows()